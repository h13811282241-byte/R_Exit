# Linux 部署指南

`r_exit_manager.py` 是一个单文件脚本，依赖少，只要把脚本和 `requirements.txt` 丢到服务器上，创建一个虚拟环境即可跑。本指南提供一个打包方式，以及在 Linux 服务器上解包、部署和后台运行的建议流程。

## 1. 打包（在本地开发机执行）

```bash
bash package.sh
```

脚本会在 `dist/` 目录下生成一个带时间戳的 `r_exit_manager_bundle_*.tar.gz`，里面包含：

- `r_exit_manager.py`
- `requirements.txt`
- 本指南

## 2. 上传到服务器

用你熟悉的方式（scp/rsync/SFTP）把生成的 tar 包上传到服务器，例如：

```bash
scp dist/r_exit_manager_bundle_*.tar.gz user@your.server:/opt/r-exit/
```

## 3. 服务器上解包 + 建虚拟环境

```bash
cd /opt/r-exit
tar xzf r_exit_manager_bundle_*.tar.gz
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

## 4. 配置 API Key

```bash
export BINANCE_API_KEY="你的 key"
export BINANCE_API_SECRET="你的 secret"
```

如果希望开机自动带上，可把上述 export 语句放进 `~/.bashrc` 或专门的 `env.sh` 中，在 systemd/cron 启动前 `source` 一下。

## 5. 运行

```bash
source /opt/r-exit/.venv/bin/activate
python r_exit_manager.py --symbol ETHUSDT --stop 3070 --poll-interval 3
```

- `--testnet`：如需跑 U 本位合约测试网附加该参数。
- 运行前确保你已经在 Binance U 本位合约手动持仓，且 `--stop` 为你预先计算的初始止损价。

## 6. 后台运行选项

### 6.1 nohup / screen / tmux

```bash
nohup /opt/r-exit/.venv/bin/python r_exit_manager.py --symbol ... > logs/run.log 2>&1 &
```

### 6.2 systemd 服务示例

`/etc/systemd/system/r-exit-manager.service`

```ini
[Unit]
Description=Binance R exit manager
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/r-exit
Environment="BINANCE_API_KEY=xxx"
Environment="BINANCE_API_SECRET=yyy"
ExecStart=/opt/r-exit/.venv/bin/python r_exit_manager.py --symbol ETHUSDT --stop 3070 --poll-interval 3
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

启用：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now r-exit-manager.service
```

## 7. 日志与升级

- 默认脚本输出到 stdout，可配合 `nohup` 或 systemd 的 journald 查阅。
- 升级脚本时重新运行 `bash package.sh` 生成新包，上传后只需覆盖 `r_exit_manager.py` 并 `systemctl restart` 即可（systemd 方案）。
